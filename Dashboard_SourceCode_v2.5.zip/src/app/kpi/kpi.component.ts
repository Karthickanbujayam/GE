//"Copyright 2018 General Electric Company. All rights reserved."
//-------------------------------------------------------//
//importing the library components start here... 
//-------------------------------------------------------//
import { Component, OnInit } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgForm } from '@angular/forms';
import { KpiServiceService } from '../services/kpiService/kpi-service.service';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { } from '../uitility/iframe/iframe.component';
declare var $: any;
import * as _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner'; 
import {AlertifyService} from '../services/alertify.service';

//-------------------------------------------------------//
//importing the library components End to here...
//-------------------------------------------------------//

@Component({
  selector: 'app-kpi',
  templateUrl: './kpi.component.html',
  styleUrls: ['./kpi.component.css'] 
})
export class KpiComponent implements OnInit {

  //-------------------------------------------------------//
//Declaring  variables end to here...
//-------------------------------------------------------//

   
  constructor(
    private kpi_data: KpiServiceService,
    private spinner: NgxSpinnerService,
    private alertify: AlertifyService
  ) {
    this.minDate = new Date();
    this.maxDate = new Date();
  }

//-------------------------------------------------------//
//Declaring  variables start from here...
//-------------------------------------------------------//

  kpiInputNameModel: any = [];
  kpiName_BuildModel: any = [];
  contextInputModel: any = [];

  kpiQueryParem: any;
  kpiNameInputs: any;
  getKPIName: any;
  kpiNameList: any;
  kpiNameBuildList: any;
  iFrameUrl: any;
  currentIframeURL: string;

  startDateInputModel = 'now-1y';
  endDateInputModel = 'now';
  hardwareConfigInputModel: any;
  hardwareValuesInputModel: any;
  kpiContextInputModel: any;
  kpiContextValuesInputModel: any;
  showStyle: any = false;
  minDate: Date;
  maxDate: Date; 
  isValid: any = true;
  public myInnerHeight: any = 600;

//-------------------------------------------------------//
//Select dropdown config start here...
//-------------------------------------------------------//


  RunContextConfig = {
    displayKey: 'RunContext', //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: '300px', //height of the list so that if there are more no of items it can show a scroll defaults to auto.
    placeholder: 'Select' // text to be displayed when no item is selected defaults to Select.
  };
  kpiNameConfig = {
    displayKey: 'kpiName', //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: '300px', //height of the list so that if there are more no of items it can show a scroll defaults to auto.
    placeholder: 'Select' // text to be displayed when no item is selected defaults to Select.
  };
  kpiBuildConfig = {
    displayKey: 'Build', //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: '300px', //height of the list so that if there are more no of items it can show a scroll defaults to auto.
    placeholder: 'Select' // text to be displayed when no item is selected defaults to Select.
  };

  /*-------------- Start Hide And Show for Filter-----------------------------*/
  toggle = true;


//-------------------------------------------------------//
//Select dropdown config end here...
//-------------------------------------------------------//

  changeValue(anyThing: any) {
    console.log(anyThing);
  } 

  ngOnInit() {  
    
    this.spinner.show();
    this.isInvalid();

    //Default iframe URL
    this.currentIframeURL = 'http://10.177.219.149:5601/app/kibana#/dashboard/2028e2d0-31a7-11e8-a8c0-fba113870975?embed=true&_g='
                          + '(refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-6M,interval:\'1d\',mode:quick,timezone:'
                          + 'Asia%2FKolkata,to:now))&_a=(description:\'Concerto+Viz+KPIs+Dashboard\',filters:!(),fullScreenMode:!f,'
                          + 'options:(darkTheme:!f,hidePanelTitles:!f,useMargins:!t),panels:!((gridData:(h:3,i:\'1\',w:4,x:0,y:0),id:'
                          + '\'4eb89f80-31a4-11e8-a8c0-fba113870975\',panelIndex:\'1\',type:visualization,version:\'6.1.1\'),(gridData:'
                          + '(h:3,i:\'2\',w:4,x:4,y:0),id:\'9d4a3090-31a5-11e8-a8c0-fba113870975\',panelIndex:\'2\',type:visualization,'
                          + 'version:\'6.1.1\'),(gridData:(h:3,i:\'7\',w:4,x:0,y:3),id:\'5f4f71e0-3337-11e8-a8c0-fba113870975\','
                          + 'panelIndex:\'7\',type:visualization,version:\'6.1.1\'),(gridData:(h:3,i:\'9\',w:4,x:8,y:0),'
                          + 'id:f5d12630-3338-11e8-a8c0-fba113870975,panelIndex:\'9\',type:visualization,version:\'6.1.1\'),'
                          + '(gridData:(h:3,i:\'10\',w:4,x:0,y:6),id:\'330ab6a0-333a-11e8-a8c0-fba113870975\',panelIndex:\'10\',type:visualization,'
                          + 'version:\'6.1.1\'),(gridData:(h:3,i:\'11\',w:4,x:4,y:3),id:d98b3570-3341-11e8-a8c0-fba113870975,panelIndex:\'11\','
                          + 'type:visualization,version:\'6.1.1\'),(gridData:(h:3,i:\'12\',w:4,x:8,y:3),id:\'73480d00-3342-11e8-a8c0-fba113870975\''
                          + ',panelIndex:\'12\',type:visualization,version:\'6.1.1\'),(gridData:(h:3,i:\'13\',w:4,x:4,y:6),'
                          + 'id:f083d5b0-3342-11e8-a8c0-fba113870975,panelIndex:\'13\',type:visualization,version:\'6.1.1\'),'
                          + '(gridData:(h:3,i:\'14\',w:4,x:8,y:6),id:\'43607360-3343-11e8-a8c0-fba113870975\',panelIndex:\'14\','
                          + 'type:visualization,version:\'6.1.1\'),(gridData:(h:3,i:\'15\',w:4,x:0,y:9),id:\'400ac340-3344-11e8-a8c0-fba113870975\''
                          + ',panelIndex:\'15\',type:visualization,version:\'6.1.1\'),(gridData:(h:3,i:\'16\',w:4,x:4,y:9),'
                          + 'id:a1906e30-3344-11e8-a8c0-fba113870975,panelIndex:\'16\',type:visualization,version:\'6.1.1\'),'
                          + '(gridData:(h:3,i:\'17\',w:4,x:8,y:9),id:\'01a79500-3345-11e8-a8c0-fba113870975\',panelIndex:\'17\''
                          + ',type:visualization,version:\'6.1.1\')),query:(language:lucene,query:\'name:+Cx_Viz_KPI_LOAD_MR32K\'),'
                          + 'timeRestore:!t,title:\'MRTF+Cx+Viz+KPIs+Dashboard\',uiState:(),viewMode:view)';
     //service call by abservable 
    // this.kpi_data.cast.subscribe(
    //   getKPINameLists => this.getKPIName = getKPINameLists
    // );

    //service call for get context name list
    this.kpi_data.getJSON().subscribe(
      data => {
        let response = data as string[];		// FILL THE ARRAY WITH DATA.   
        response = _.filter(response);

        this.kpiQueryParem = response;
        //this.alertify.success('successfully loaded program context name List in list');
        this.spinner.hide();
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
        this.alertify.error('Context Name List - API Service has Down!'); 
        this.spinner.hide();
      }
    );

    //service call for get kpi name list
    this.kpi_data.getKPINameList().subscribe(
      data => {
        let response = data as string[];		// FILL THE ARRAY WITH DATA.   
        response = _.filter(response);
        this.kpiNameInputs = response;
        this.spinner.hide();
        //this.alertify.success('successfully loaded Kpi name List in list'); 
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
        this.alertify.error('KPI Name List - API Service has Down!'); 
        this.spinner.hide();
      }
    );


    /*--------------------------------------------------------*/
    $('.fScreen').click(function (e) {
      // $(this).('.fScreenContent').toggleClass('fullscreen');
      $(this).toggleClass('fullscreen').toggleClass('');
    });


    /*--------------------------------------------------------*/
  }
  toggleElement() { this.toggle = !this.toggle; }
  getStyle() {
    if (this.showStyle) {
      return 'none';
    } else {
      return 'block';
    }
  }
  /*--------------End Hide And Show for Filter-----------------------------------*/

  onKpiDisplayReports(kpiForm: NgForm): void {
    console.log(kpiForm);
  }

  onStartDateSelect($event) {
     //console.log(new Date(new Date($event).toString().split('GMT')[0]+' UTC').toISOString());
     //console.log($event);
     this.startDateInputModel = '\'' + new Date(new Date($event).toString().split('GMT')[0] + ' UTC').toISOString() + '\'';
     this.isInvalid( );
   }
   onEndDateSelect($event) {
    //   console.log(new Date(new Date($event).toString().split('GMT')[0]+' UTC').toISOString(););
      // console.log($event);
       this.endDateInputModel = '\'' + new Date(new Date($event).toString().split('GMT')[0] + ' UTC').toISOString() + '\'';
       this.isInvalid( );
      }

   fScreenClick(event) {
    // event.target.classList.add('fullscreen'); // To ADD
    // event.target.classList.remove('fullscreen'); // To Remove
    // event.target.classList.close('click'); // To check 
    event.currentTarget.parentNode.classList.toggle('fullscreen');
      if ( this.myInnerHeight + 100 != window.innerHeight ) {
      this.myInnerHeight = window.innerHeight - 100;
    } else {
      this.myInnerHeight = 600;
    } 
  }

  onItemChangeRunContext($event: any) {
    //console.log($event.value);
    this.contextInputModel = $event.value;
    this.isInvalid( );
  }

  onItemChangeKIPName($event: any) {
    //console.log($event);
    this.kpiInputNameModel = $event.value;
    //console.log(this.kpiInputNameModel);
    this.isInvalid( );
  }
  isInvalid() {
    //console.log(this.isValid);
    //console.log(this.kpiInputNameModel[0]+ "************" + this.contextInputModel[0]+ "***********" );
    if ((this.kpiInputNameModel[0] != undefined) && (this.contextInputModel[0] != undefined)) {
      this.isValid = false;
      //console.log(this.isValid);
    } else {
      this.isValid = true;
    }
  }
  appendToNewIframe( ) {
    this.kpi_data.getdata_KpiNameID().subscribe(
      data => {
        const response = data as string[];		// FILL THE ARRAY WITH DATA.   
        // response = _.filter(response);  
        this.kpiNameList = _.map(response, function (value, prop) {
          return { prop: value, value: prop };
        });
        const arr = [];
        for (let i = 0; i < this.kpiInputNameModel.length; i++) {  //selected item
          for (let j = 0; j < this.kpiNameList.length; j++) {
            if (this.kpiInputNameModel[i] == this.kpiNameList[j].prop) {
              arr.push(this.kpiNameList[j]);
              //console.log('Selected kpiNameList : ' + arr[i]); 
            }
          }
        }
        console.log(arr);
        const KIBANA_HOST = 'http://10.177.219.149:5601/';
        const OPTIONAL_DASHBOARD_NAME = '64c32c50-3631-11e8-a8c0-fba113870975';
        const GLOBAL_STATE_DATA = 'refreshInterval:(display:Off,pause:!f,value:0),time:(from:' + this.startDateInputModel + ',interval:\'1d\',mode:quick,timezone:Asia%2FKolkata,to:' + this.endDateInputModel + '))';
        let tempStr = '';
        let UpdateStr = '';

        for (let i = 0; i < arr.length; i++) {  //selected item 6 
          for (let k = 0; k < arr.length; k += 3) { // 0,3,6
            for (let j = 0; j <= 8; j += 4) { // 0,4,8
              //console.log(j, k);
              if (arr[i] != undefined) {
                UpdateStr = '(gridData:(h:3,i:\'' + i + '\',w:4,x:' + j + ',y:' + k + '),id:\'' + arr[i].value + '\',panelIndex:\'' + i + '\',type:visualization,version:\'6.1.1\')';
                i++;
                if (tempStr == '') {
                  tempStr = UpdateStr;
                } else {
                  tempStr = tempStr + ',' + UpdateStr;
                }
              }
            }
          } 

        } 
        const KIBANA_CHARTS_LIST = tempStr;
        const APP_STATE_DATA = '(description:\'Rio+Viz+KPIs+Dashboard\',filters:!(),fullScreenMode:!f,options:(darkTheme:!f,hidePanelTitles:!f,useMargins:!t),panels:!(' + KIBANA_CHARTS_LIST + '),query:(language:lucene,query:\'RunContext:' + this.contextInputModel + '\'),timeRestore:!t,title:\'MRTF+Rio+Viz+KPIs+Dashboard\',uiState:(),viewMode:view)';
        this.currentIframeURL = KIBANA_HOST + 'app/kibana#/dashboard/' + OPTIONAL_DASHBOARD_NAME + '?embed=true&_g=(' + GLOBAL_STATE_DATA + '&_a=' + APP_STATE_DATA;
        $('#iFrame_ID').attr('src', this.currentIframeURL); 
         },
      (err: HttpErrorResponse) => {
        console.log(err.message);
        this.alertify.error('Kibana Dashboard URL Not Accessable Due To Network'); 
        this.spinner.hide();
      }
    );

  }
}



