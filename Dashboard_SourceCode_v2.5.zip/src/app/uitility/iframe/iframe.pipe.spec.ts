import { IframePipe } from './iframe.pipe'; 
import { DomSanitizer, SafeHtml, SafeStyle, SafeScript, SafeUrl, SafeResourceUrl } from '@angular/platform-browser';

describe('IframePipe', () => {
  // it('create an instance', () => {
  //   const pipe = new IframePipe();
  //   expect(pipe).toBeTruthy();
  // });
  
});
