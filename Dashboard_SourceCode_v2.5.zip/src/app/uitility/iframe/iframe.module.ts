//"Copyright 2018 General Electric Company. All rights reserved."
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IframeComponent } from './iframe.component';
import { IframePipe } from './iframe.pipe';

@NgModule({
  declarations: [IframeComponent, IframePipe],
  imports: [CommonModule, FormsModule],
  exports: [IframeComponent],
  providers: [],
  bootstrap: []
})
export class IframeModule {}
