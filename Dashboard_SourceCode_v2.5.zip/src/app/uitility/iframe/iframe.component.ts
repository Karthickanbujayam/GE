//"Copyright 2018 General Electric Company. All rights reserved."
import { Component, Input, OnInit } from '@angular/core';  
import {BrowserModule, DomSanitizer} from '@angular/platform-browser'; 
import { FormsModule } from '@angular/forms'; 
import {KpiComponent} from '../../kpi/kpi.component';
declare var $: any;

@Component({
  selector: 'app-iframe',
  templateUrl: './iframe.component.html',
  styleUrls: ['./iframe.component.css']
})
export class IframeComponent implements OnInit {
   @Input() iFrameURL: string;
   @Input() myInnerHeight: number;
   _URL: any; 
   constructor(private sanitizer: DomSanitizer) { } 
   ngOnInit() { }  
}
