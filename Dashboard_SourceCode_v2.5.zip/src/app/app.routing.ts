import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component'; 
import { KpiComponent } from './kpi/kpi.component';  
import {DeveloperViewsComponent} from './developer-views/developer-views.component';
import { SummaryViewComponent } from './developer-views/summary-view/summary-view.component';


const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', loadChildren: 'src/app/dashboard/dashboard.module#DashboardModule' },
  { path: 'kpi', component: KpiComponent },  
  { path: 'developerViews', component: DeveloperViewsComponent} ,
  //{ path: 'developerViews/:runidinfo', component: DeveloperViewsComponent },
  { path:  '**', component: DeveloperViewsComponent }
]; 

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
