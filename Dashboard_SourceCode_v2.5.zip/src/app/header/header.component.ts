//"Copyright 2018 General Electric Company. All rights reserved."
import { Component, OnInit } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  status : boolean;
  public isViewable: boolean;

  constructor() { }

   
 public enableRow(): void { 
   this.status = !this.status;
   this.isViewable = !this.isViewable;
   }
  ngOnInit() {
    this.isViewable = true;
  }

}
