//*************Module Level***************************/
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core'; 
import { AngularFontAwesomeModule } from 'angular-font-awesome'; 
import { RouterModule } from '@angular/router';
import { routing } from './app.routing'; 
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms'; 
import { CommonModule, formatNumber } from '@angular/common';
import {SelectDropDownModule} from './uitility/ngx-select-dropdown/ngx-select-dropdown.module';
import {IframeModule} from './uitility/iframe/iframe.module'; 
//import {DeveloperViewsModule} from './developer-views/developerviews.module';    
import {DashboardModule} from './dashboard/dashboard.module';
import { NgxSpinnerModule } from 'ngx-spinner';   
import {SlimLoadingBarModule} from 'ng2-slim-loading-bar';  
import { BsDatepickerModule } from 'ngx-bootstrap'; 
import {DataTableModule} from 'angular2-datatable'; 

//*************Component Level***************************/
import { AppComponent } from './app.component'; 
import { HeaderComponent } from './header/header.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { DashboardComponent } from './dashboard/dashboard.component'; 
import { KpiComponent } from './kpi/kpi.component'; 
import {DeveloperViewService} from './services/DeveloperViewService'; 
import {ExcelService} from './services/ExcelService';   
import {KpiServiceService} from './services/kpiService/kpi-service.service'; 
import {HttpInterceptor} from './uitility/HTTPInterceptor';   
import {DashboardCartsInfoComponent} from './dashboard/dashboard-carts-info/dashboard-carts-info.component';
import {AlertifyService} from '../app/services/alertify.service';   
import { DeveloperViewsComponent } from './developer-views/developer-views.component';
import {SummaryViewComponent} from './developer-views/summary-view/summary-view.component';
import { SearchFilterPipe } from './pipes/search-filter.pipe';
import { SlicePipePipe } from './pipes/slice-pipe.pipe';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    NavBarComponent,
    DashboardComponent,  
    KpiComponent, 
    DashboardCartsInfoComponent, 
    DeveloperViewsComponent,
    SummaryViewComponent,
    SearchFilterPipe,
    SlicePipePipe
  ],
  imports: [
    BrowserModule,
    CommonModule,
    routing,
    RouterModule,
    AngularFontAwesomeModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    SelectDropDownModule,
    IframeModule,
   // DeveloperViewsModule,
    NgxSpinnerModule,
    DashboardModule,
    SlimLoadingBarModule.forRoot(),
    BsDatepickerModule.forRoot(), 
    DataTableModule,
    
  ],
  exports: [SlimLoadingBarModule],
  providers: [KpiServiceService,
              HttpInterceptor,
              DeveloperViewService,
              ExcelService,
              AlertifyService,
            ],
  bootstrap: [AppComponent]
})
export class AppModule {}
