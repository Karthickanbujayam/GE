//"Copyright 2018 General Electric Company. All rights reserved."
import { Component, OnInit } from '@angular/core';
declare var $: any; 

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $('.sidebar-nav li a').click(function(e) { 
      $('.sidebar-nav li.active').removeClass('active'); 
      const $parent = $(this).parent();
      $parent.addClass('active');
      e.preventDefault();
  });
  }

}
