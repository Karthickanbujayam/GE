
//"Copyright 2018 General Electric Company. All rights reserved."
import { Component, OnInit, Input } from '@angular/core'; 
import { Http, Response } from '@angular/http';
import { map } from 'rxjs/operators';
import { DeveloperViewService } from '../../services/DeveloperViewService';
import { HttpErrorResponse } from '@angular/common/http/src/response';
declare var $: any;
import * as _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner'; 
import {AlertifyService} from '../../services/alertify.service';  
import { Router, ActivatedRoute, Params } from '@angular/router'; 
import { ExcelService } from '../../services/ExcelService';

@Component({
  selector: 'app-summary-view',
  templateUrl: './summary-view.component.html',
  styleUrls: ['./summary-view.component.css']
})
export class SummaryViewComponent implements OnInit {

 

  @Input() contextNameModelDev: any;
  @Input() systemtypeModelDev: any; 
  @Input() locationInputModelDev: any; 
  @Input() runNameInputModelDev: any; 
  @Input() runResultInputModelDev: any; 
  @Input() runStatusInputModelDev: any;  
  @Input() startDateInputDevModelDev: any;  
  @Input() endDateInputDevModelDev: any;  
  @Input() runIDInputModelDev: any;  

  runInfoSummary: any;
  TestInfoSummary: any; 
  currentRow_RunID: any;
  currentRow: any;
  testIdInfo: any;
  currentTestRow_RunID: any;
  currentTestRow: any;
  TestDetailsInfoSummary: any;
  filterObject: any; 
  currentTestRow_TestId: any;
  RunId: any;
  RunIdParams: any; 
  TestDetailsInfoSummaryInfo: any;
 downloadUrl: any;
  

  selectedRow(event: any, item: any) {
      console.log('this.item' + JSON.stringify(item) );
      this.currentRow_RunID = item.RunID;
      //this.currentRow = JSON.stringify(item); 
      item.expanded = ! item.expanded; 
      this.expandtestdata(this.currentRow_RunID);
   
  } 

  selectedTestRow(event: any, testItem: any) { 
    this.currentTestRow_TestId = testItem.TestId;
    console.log('this.currentTestRow_TestId :' + this.currentTestRow_TestId);
    //this.currentTestRow = JSON.stringify(testItem); 
    testItem.expanded = ! testItem.expanded; 
    this.expandtestDetaildata(testItem.TestId); 
}

 expandtestdata(data) { 
    this._developerviewservice.getTestInfoSummary(data).subscribe(Responsed => {
      this.TestInfoSummary = Responsed.data;  
  }); 
  } 

expandtestDetaildata(test_ID) { 
  this._developerviewservice.getTestDetailsInfoSummary(test_ID).subscribe(data => { 
    console.log(data.data); 
    data.data[0]['testId'] = data.testId;
    data.data[0]['testName'] =  data.testName; 
    data.data[0]['download_autotest'] =  this.downloadUrl + data.data[0].RPath + '/' + data.data[0].testName + '/autotest.log';
    data.data[0]['download_gesys'] =  this.downloadUrl + data.data[0].RPath + '/' + data.data[0].testName + '/gesys_MRSATVM15.log';
    data.data[0]['download_KPI_log'] =  this.downloadUrl + data.data[0].RPath + '/' + data.data[0].testName + '/KPI.log';
    data.data[0]['download_protocolUp'] =  this.downloadUrl + data.data[0].RPath + '/' + data.data[0].testName + '/protocolUp';
    data.data[0]['download_resultsFile_xml'] =  this.downloadUrl + data.data[0].RPath + '/' + data.data[0].testName + '/resultsFile.xml'; 
    data.data[0]['download_testName'] =  this.downloadUrl + data.data[0].RPath + '/' + data.data[0].testName + data.data[0].testName + '.zip';
   
   console.log(data.data);
    this.TestDetailsInfoSummary = data.data;
  
    
    console.log(this.TestDetailsInfoSummary);
}); 
}

exportToExcel() {
  this._developerviewservice.getrunInfoSummary()
      .subscribe(data => { 
          this.excelService.exportAsExcelFile(data.data, 'AllRunInfoData');
      });

}
 

  constructor(private _developerviewservice: DeveloperViewService, 
    private http: Http,
    private spinner: NgxSpinnerService,
    private alertify: AlertifyService,
    private route: ActivatedRoute,
    private excelService: ExcelService) {  

          this.RunIdParams = route.snapshot.params['runidinfo'];
          console.log(this.RunIdParams); 
          if (this.RunIdParams) {
            this.runIDInputModelDev =  this.RunIdParams;
          }
    }

  ngOnInit() { 
    this.downloadUrl = 'http://3.204.28.80';
    this.testIdInfo = false; 

    $(function () {
      $('[data-toggle=\'tooltip\']').tooltip();
    });

    this._developerviewservice.getrunInfoSummary().subscribe(data => {
      this.runInfoSummary = data.data; 
      console.log(data.data);
      console.log('runInfoSummary' + this.runInfoSummary);
  });

  $(document).ready(function() {
    $('#myInput').on('keyup', function() {
      const value = $(this).val().toLowerCase();
      $('#myTable tr').filter(function() {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
      });
    });
  });
 

  }

}
