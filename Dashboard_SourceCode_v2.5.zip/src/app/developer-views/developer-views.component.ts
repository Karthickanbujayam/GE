import { Component, OnInit } from '@angular/core';
import { Http, Response } from '@angular/http';
import { map } from 'rxjs/operators';
import { DeveloperViewService } from '../services/DeveloperViewService';
import { HttpErrorResponse } from '@angular/common/http/src/response';
declare var $: any;
import * as _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { AlertifyService } from '../services/alertify.service';
import { SummaryViewComponent } from './summary-view/summary-view.component';
import { Router, ActivatedRoute, Params } from '@angular/router'; 
import {Observable} from 'rxjs/Observable';

@Component({
  selector: 'app-developer-views',
  templateUrl: './developer-views.component.html',
  styleUrls: ['./developer-views.component.css'],
  providers: [DeveloperViewService],
})
export class DeveloperViewsComponent implements OnInit {

  public current: Observable<any>;
  private observer: any;

  contextQueryParem: any;
  systemtype_QueryParem: any;
  location_QueryParem: any;
  runName_QueryParem: any;
  runResult_QueryParem: any;
  runStatus_QueryParem: any;
  contextNameModel: any = '';
  systemtypeModel: any = '';
  locationInputModel: any = '';
  runNameInputModel: any = '';
  runResultInputModel: any = '';
  runStatusInputModel: any = '';
  startDateInputDevModel: any = '';
  endDateInputDevModel: any = '';
  runIDInputModel: any = '';
  filterObject: any[];
  RunIdParams: any; 
  RunIdParamsModel: any;
  TestDetailsInfoSummary: any;
  private data: Observable<string>;
  QueryParam: any;
  maxDate: Date;

  ContextNameConfig = {
    displayKey: 'ContextName', //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: '300px', //height of the list so that if there are more no of items it can show a scroll defaults to auto.
    placeholder: 'Select' // text to be displayed when no item is selected defaults to Select.
  };

  systemtypeConfig = {
    displayKey: 'ContextName', //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: '300px', //height of the list so that if there are more no of items it can show a scroll defaults to auto.
    placeholder: 'Select' // text to be displayed when no item is selected defaults to Select.
  };

  locationConfig = {
    displayKey: 'ContextName', //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: '300px', //height of the list so that if there are more no of items it can show a scroll defaults to auto.
    placeholder: 'Select' // text to be displayed when no item is selected defaults to Select.
  };

  runNameConfig = {
    displayKey: 'ContextName', //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: '300px', //height of the list so that if there are more no of items it can show a scroll defaults to auto.
    placeholder: 'Select' // text to be displayed when no item is selected defaults to Select.
  };

  runResultConfig = {
    displayKey: 'ContextName', //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: '300px', //height of the list so that if there are more no of items it can show a scroll defaults to auto.
    placeholder: 'Select' // text to be displayed when no item is selected defaults to Select.
  };

  runStatusInputConfig = {
    displayKey: 'ContextName', //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: '300px', //height of the list so that if there are more no of items it can show a scroll defaults to auto.
    placeholder: 'Select' // text to be displayed when no item is selected defaults to Select.
  };



  onItemChangeDevContextName($event: any) {
    //console.log($event.value);
    this.contextNameModel = $event.value;
  }

  onItemChangeSystemtypeInput($event: any) {
    //console.log($event.value);
    this.systemtypeModel = $event.value;
  }

  onItemChangelocationInput($event: any) {
    //console.log($event.value);
    this.locationInputModel = $event.value;
  }

  onItemChangeRunNameInput($event: any) {
    //console.log($event.value);
    this.runNameInputModel = $event.value;
  }
  onItemChangeRunResultInput($event: any) {
    //console.log($event.value);
    this.runResultInputModel = $event.value;
  }
  onItemChangeRunStatusInput($event: any) {
    //console.log($event.value);
    this.runStatusInputModel = $event.value;
  }

  onItemChangeRunIDInput($event: any) {
    console.log($event.value);
    this.runIDInputModel = $event.value;
  }


  onStartDateSelect($event) {
    this.startDateInputDevModel = new Date(new Date($event).toISOString());
  }
  onEndDateSelect($event) {
    this.endDateInputDevModel = new Date(new Date($event).toISOString());
  }

  onKey(value: string) {
    this.runIDInputModel += value + ' | ';
  }

  clearAllInputs($event) {
    this.contextNameModel = '';
    this.systemtypeModel = '';
    this.locationInputModel = '';
    this.startDateInputDevModel = '';
    this.endDateInputDevModel = '';
    this.runNameInputModel = '';
    this.runResultInputModel = '';
    this.runStatusInputModel = '';
    this.runIDInputModel = '';
    this.RunIdParamsModel = ''; 
  } 

  constructor(
    private _developerviewservice: DeveloperViewService,
    private http: Http,
    private spinner: NgxSpinnerService,
    private alertify: AlertifyService,
    private route: ActivatedRoute) {  
          this.route.queryParamMap.subscribe(QueryParamSting => {
            this.QueryParam = QueryParamSting;
              this.RunIdParamsModel =  this.QueryParam.params.RunID;
          }); 
  }


  ngOnInit() { 
    //RunContext dropdown binding  
    this._developerviewservice.getrunInfoContext().subscribe(
      data => {
        let response = data as string[];		// FILL THE ARRAY WITH DATA.   
        response = _.filter(response);
        this.contextQueryParem = response;
       //this.alertify.success('successfully loaded RunContext dropdown binding in dropdown');
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
        this.alertify.error('KPI Name List - API Service has Down!');
        this.spinner.hide();
      }
    );

    //SystemType dropdown binding 
    this._developerviewservice.getrunInfoSystemType().subscribe(
      data => {
        let response = data as string[];		// FILL THE ARRAY WITH DATA.   
        response = _.filter(response);
        this.systemtype_QueryParem = response;
       // this.alertify.success('successfully loaded SystemType dropdown binding in dropdown');
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
        this.alertify.error('SystemType dropdown binding - API Service has Down!');
        this.spinner.hide();
      }
    );

    //Location dropdown binding 
    this._developerviewservice.getrunInfoLocation().subscribe(
      data => {
        let response = data as string[];		// FILL THE ARRAY WITH DATA.   
        response = _.filter(response);
        this.location_QueryParem = response;
      //  this.alertify.success('successfully loaded Location dropdown binding  in dropdown');
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
        this.alertify.error('Location dropdown binding  - API Service has Down!');
        this.spinner.hide();
      }
    );


    //RunName dropdown binding
    this._developerviewservice.getrunInfoRunName().subscribe(
      data => {
        let response = data as string[];		// FILL THE ARRAY WITH DATA.   
        response = _.filter(response);
        this.runName_QueryParem = response;
        //this.alertify.success('successfully loaded RunName dropdown binding in dropdown');
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
        this.alertify.error('RunName dropdown binding - API Service has Down!');
        this.spinner.hide();
      }
    );

    //RunResult dropdown binding 
    this._developerviewservice.gerrunInfoRunResult().subscribe(
      data => {
        let response = data as string[];		// FILL THE ARRAY WITH DATA.   
        response = _.filter(response);
        this.runResult_QueryParem = response;
       // this.alertify.success('successfully loaded RunResult dropdown binding in dropdown');
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
        this.alertify.error('RunResult dropdown binding - API Service has Down!');
        this.spinner.hide();
      }
    );

    //RunStatus dropdown bindning 
    this._developerviewservice.getrunInfoRunStatus().subscribe(
      data => {
        let response = data as string[];		// FILL THE ARRAY WITH DATA.   
        response = _.filter(response);
        this.runStatus_QueryParem = response;
       // this.alertify.success('successfully loaded RunStatus dropdown bindning in dropdown');
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
        this.alertify.error('RunStatus dropdown bindning in dropdown - API Service has Down!');
        this.spinner.hide();
      }
    );  
  }

}
