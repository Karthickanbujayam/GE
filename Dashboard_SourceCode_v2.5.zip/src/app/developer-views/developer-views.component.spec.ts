import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeveloperViewsComponent } from './developer-views.component';

describe('DeveloperViewsComponent', () => {
  let component: DeveloperViewsComponent;
  let fixture: ComponentFixture<DeveloperViewsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeveloperViewsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeveloperViewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
