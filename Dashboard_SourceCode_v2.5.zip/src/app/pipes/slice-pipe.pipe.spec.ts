import { SlicePipePipe } from './slice-pipe.pipe';

describe('SlicePipePipe', () => {
  it('create an instance', () => {
    const pipe = new SlicePipePipe();
    expect(pipe).toBeTruthy();
  });
});
