import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchFilter'
})
export class SearchFilterPipe implements PipeTransform {
  transform(items: any[], contextNameModelDev: any, systemtypeModelDev: any, locationInputModelDev: any, startDateInputDevModelDev: any, endDateInputDevModelDev: any, runNameInputModelDev: any, runResultInputModelDev: any, runStatusInputModelDev: any, runIDInputModelDev: any) {
    console.log(items);
    if (items && items.length) {
      return items.filter(item => {

        if (contextNameModelDev && item.Context.toLowerCase().indexOf(contextNameModelDev[0].toLowerCase()) === -1) {
          return false;
        }
        if (systemtypeModelDev && item.Type.toLowerCase().indexOf(systemtypeModelDev[0].toLowerCase()) === -1) {
          return false;
        }
        if (locationInputModelDev && item.Location.toLowerCase().indexOf(locationInputModelDev[0].toLowerCase()) === -1) {
          return false;
        }
        // if (startDateInputDevModelDev && item.Date.toLowerCase().indexOf(startDateInputDevModelDev[0].toLowerCase()) === -1) {
        //return false;
        if (startDateInputDevModelDev && item.Date) {
          const str_startDate = startDateInputDevModelDev;
          const startDateInputVal_startDate = new Date(str_startDate);
          const str_db_startDate = item.Date;
          const startDateInputVal_db_startDate = new Date(str_db_startDate);
          if (startDateInputVal_startDate >= startDateInputVal_db_startDate) {
            return false;
          }
        }
        if (endDateInputDevModelDev && item.Date) {
          const str_endDate = endDateInputDevModelDev;
          const endDateInputVal_endDate = new Date(str_endDate);
          const str_db_endDate = item.Date;
          const endDateInputVal_db_endDate = new Date(str_db_endDate);
          if (endDateInputVal_endDate <= endDateInputVal_db_endDate) {
            return false;
          }

        }
        if (runNameInputModelDev && item.TestSetName.toLowerCase().indexOf(runNameInputModelDev[0].toLowerCase()) === -1) {
          return false;
        }
        if (runResultInputModelDev && item.Result.toLowerCase().indexOf(runResultInputModelDev[0].toLowerCase()) === -1) {
          return false;
        }
        if (runStatusInputModelDev && item.Status.toLowerCase().indexOf(runStatusInputModelDev[0].toLowerCase()) === -1) {
          return false;
        }
        if (runIDInputModelDev && item.RunID.toString() !== runIDInputModelDev) {
          return false;
        }
        return true;
      });
    } else {
      return items;
    }
  }

}
