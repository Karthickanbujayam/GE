//"Copyright 2018 General Electric Company. All rights reserved."
import { Injectable } from '@angular/core';
import { Http } from '@angular/http'; 
import { Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { map } from 'rxjs/operators'; 
import { BehaviorSubject } from 'rxjs';
import { HttpInterceptor } from '../../uitility/HTTPInterceptor';

@Injectable({
  providedIn: 'root'
})
export class KpiServiceService {
  public message = 'Testing service';
  //private _url: string = "assets/data/fetchAll.json";
  private _url = 'http://3.204.110.149:5010/runContextsList';
  private kpiNamesList: any[];
  private getKPINameLists = new BehaviorSubject('All');
  
  //cast = this.getKPINameLists.asObservable();


  constructor(
    public http: HttpInterceptor 
  ) { } 

  getJSON() {
    return this.http.get(this._url).map(response => response.json());  
  }   

  getdata_KpiRunContext() {
    return this.http.get(this._url).map((res: Response) => res.json()) 
    .catch((err) => { 
      if (err.status = 404) {
        alert(err);  
      }
      // Do messaging and error handling here 
      return Observable.throw(err);
  });
  }


  getdata_KpiNameID() {
    return this.http.get('http://3.204.110.149:5010/kpiVizIds').map((res: Response) => res.json()) 
    .catch((err) => { 
      if (err.status = 404) {
        alert(err);  
      }
      // Do messaging and error handling here 
      return Observable.throw(err);
  });
  } 

  
  getKPINameList() {
    const urlWithId = 'http://3.204.110.149:5010/kpiVizIds';
      return  this.http.get(urlWithId).map((res: Response) => res.json()) 
        .catch((err) => { 
          if (err.status = 404) {
            alert(err);  
          }
          // Do messaging and error handling here 
          return Observable.throw(err);
      });
  }
    

    getBuildList(kpiName:  string ) {
      console.log('Calling KPI name list service');

      const urlWithId = 'http://3.204.110.149:5010/kpiBuildsList/' + kpiName;
      //const urlWithId = "assets/data/fetchAll.json";
        return this.http.get(urlWithId).map((res: Response) => res.json()) 
        .catch((err) => { 
          if (err.status = 404) {
            alert(err); 
          }
          // Do messaging and error handling here 
          return Observable.throw(err);
      });

    }
  


}

 
