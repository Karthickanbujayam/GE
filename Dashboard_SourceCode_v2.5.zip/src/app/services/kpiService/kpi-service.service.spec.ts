import { TestBed, inject } from '@angular/core/testing';

import { KpiServiceService } from './kpi-service.service';

describe('KpiServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [KpiServiceService]
    });
  });

  it('should be created', inject([KpiServiceService], (service: KpiServiceService) => {
    expect(service).toBeTruthy();
  }));
});
