//"Copyright 2018 General Electric Company. All rights reserved."
import { Injectable } from '@angular/core'; 
import { Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { map } from 'rxjs/operators'; 
import { BehaviorSubject } from 'rxjs';
import { HttpInterceptor } from '../uitility/HTTPInterceptor';


@Injectable({
  providedIn: 'root'
})
export class DeveloperViewService {

    constructor(private http: HttpInterceptor) {}

    private _url = 'assets/samplejson/dashboard.json';
    ngOnInit() {}

    gethomedata() {
      return this.http.get(this._url).pipe(map(response => response.json()));
    }

    getrunInfoContext() { 
      return this.http.get('http://3.204.110.149:5010/runInfo/Context').map((res: Response) => res.json()) 
      .catch((err) => { 
        if (err.status = 404) {
          alert(err);  
        }
        // Do messaging and error handling here 
        return Observable.throw(err);
    }); 
    }

    getrunInfoSystemType() {  
      return this.http.get('http://3.204.110.149:5010/runInfo/Type').map((res: Response) => res.json()) 
      .catch((err) => { 
        if (err.status = 404) {
          alert(err);  
        }
        // Do messaging and error handling here 
        return Observable.throw(err);
    });

      
    }

    getrunInfoLocation() { 
      return this.http.get('http://3.204.110.149:5010/runInfo/Location').map((res: Response) => res.json()) 
      .catch((err) => { 
        if (err.status = 404) {
          alert(err);  
        }
        // Do messaging and error handling here 
        return Observable.throw(err);
    });
      
    }

    getrunInfoRunName() { 
      return this.http.get('http://3.204.110.149:5010/runInfo/TestSetName').map((res: Response) => res.json()) 
      .catch((err) => { 
        if (err.status = 404) {
          alert(err);  
        }
        // Do messaging and error handling here 
        return Observable.throw(err);
    });
      
 
    }

    gerrunInfoRunResult() { 
      return this.http.get('http://3.204.110.149:5010/runInfo/Result').map((res: Response) => res.json()) 
      .catch((err) => { 
        if (err.status = 404) {
          alert(err);  
        }
        // Do messaging and error handling here 
        return Observable.throw(err);
    });
 
    }

    getrunInfoRunStatus() {  
      return this.http.get('http://3.204.110.149:5010/runInfo/Status').map((res: Response) => res.json()) 
      .catch((err) => { 
        if (err.status = 404) {
          alert(err);  
        }
        // Do messaging and error handling here 
        return Observable.throw(err);
    });
  
    }

    getrunInfoRunDetail() { 
      return this.http.get('http://3.204.110.149:5005/allRunDetailData').map((res: Response) => res.json()) 
      .catch((err) => { 
        if (err.status = 404) {
          alert(err);  
        }
        // Do messaging and error handling here 
        return Observable.throw(err);
    });
     
    }

    getrunInfoSummary() { 
      return this.http.get('http://3.204.110.149:5005/allRunInfoData').map((res: Response) => res.json()) 
      .catch((err) => { 
        if (err.status = 404) {
          alert(err);  
        }
        // Do messaging and error handling here 
        return Observable.throw(err);
    });
    }


    getTestInfoSummary(runID) { 
      console.log(runID);
      return this.http.get('http://3.204.110.149:5005/runInfo/testInfo/runId/' + runID).map((res: Response) => res.json()) 
      .catch((err) => { 
        if (err.status = 404) {
          alert(err);  
        }
        // Do messaging and error handling here 
        return Observable.throw(err);
    });
    } 


    getTestDetailsInfoSummary(test_ID) { 
      return this.http.get('http://3.204.110.149:5005/allTestInfoData/' + test_ID).map((res: Response) => res.json()) 
      .catch((err) => { 
        if (err.status = 404) {
          alert(err);  
        }
        // Do messaging and error handling here 
        return Observable.throw(err);
    });
    } 


}


