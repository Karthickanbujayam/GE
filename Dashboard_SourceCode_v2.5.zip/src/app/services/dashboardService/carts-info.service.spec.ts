import { TestBed, inject } from '@angular/core/testing';

import { CartsInfoServices } from './carts-info.service';

describe('CartsInfoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CartsInfoServices]
    });
  });

  it('should be created', inject([CartsInfoServices], (service: CartsInfoServices) => {
    expect(service).toBeTruthy();
  }));
});
