//"Copyright 2018 General Electric Company. All rights reserved."
import { Injectable } from '@angular/core';
import { Http } from '@angular/http'; 
import { Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { map } from 'rxjs/operators'; 
import { BehaviorSubject } from 'rxjs';
import { HttpInterceptor } from '../../uitility/HTTPInterceptor'; 

@Injectable({
  providedIn: 'root'
})
export class CartsInfoServices {
  
  constructor(
    public http: Http 
  ) { } 

  getdata_cartsInfo(context) {
    console.log('http://3.204.110.149:5005/allRunInfoData/' + context + '/2');
      return this.http.get('http://3.204.110.149:5005/allRunInfoData/' + context + '/2').map((res: Response) => res.json()) 
      .catch((err) => { 
        if (err.status = 404) {
          // alert(err);   
        }
        // Do messaging and error handling here 
        return Observable.throw(err);
      });
  }

  getKPINameList() {
    const urlWithId = 'http://3.204.110.149:5010/runContextsList';
      return this.http.get(urlWithId).map((res: Response) => res.json()) 
        .catch((err) => { 
          if (err.status = 404) {  
            // alert(err);  
          }
          // Do messaging and error handling here 
          return Observable.throw(err);
      });
  }

  CartsInfoRefresh(programeName) {
    console.log('http://3.204.110.149:5005/allRunInfoData/' + programeName + '/2'); 
    return this.http.get('http://3.204.110.149:5005/allRunInfoData/' + programeName + '/2').map((res: Response) => res.json()) 
    .catch((err) => { 
      if (err.status = 404) {
        // alert(err);   
      }
      // Do messaging and error handling here 
      return Observable.throw(err);
    });
  }


}
