// import { Injectable } from '@angular/core';
// import { BehaviorSubject } from 'rxjs';
// @Injectable()
// export class ParentChildService {
//    data:any;
//    summarydata:any;


//   public messageSource = new BehaviorSubject<any[]>([]);

//    currentdata = this.messageSource.asObservable();

//   constructor() { }

//   changedata(val: any[]) {
//     this.messageSource.next(val);
//     this.data =val;
//     console.log(this.data);
//     return this.data;
//   }
    
//   // summarydata= this.currentdata;
  

// }
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
@Injectable()
export class ParentChildService {
   data: any;
   summarydata: any;


  public messageSource: any;

  //  currentdata = this.messageSource.asObservable();

  constructor() { }

  changedata(val: any[]) {
    this.messageSource = val;
    this.data = this.messageSource;
    console.log(this.data);
    return this.data;
  }
    
  // summarydata= this.currentdata;
  

}
