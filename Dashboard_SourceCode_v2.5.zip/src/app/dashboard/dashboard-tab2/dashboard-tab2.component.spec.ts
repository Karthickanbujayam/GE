import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardTab2Component } from './dashboard-tab2.component';

describe('DashboardTab2Component', () => {
  let component: DashboardTab2Component;
  let fixture: ComponentFixture<DashboardTab2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardTab2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardTab2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
