//© Copyright 2018-2019, GE
import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'; 
import {DashboardComponent} from './dashboard.component';
import { DashboardTab1Component } from './dashboard-tab1/dashboard-tab1.component';
import { DashboardTab2Component } from './dashboard-tab2/dashboard-tab2.component'; 

const routes: Routes = [ 
{ path: '', redirectTo: 'dashboard', pathMatch: 'full' }, 
{ path: 'dashboard', component: DashboardComponent,
    children: [
        { path: '', redirectTo: 'RunContext', pathMatch: 'full' },
        { path: 'RunContext', component: DashboardTab1Component},
        {path: 'KpiView', component: DashboardTab2Component} 
    ]}
];
 
export const routing: ModuleWithProviders = RouterModule.forChild(routes);
 
