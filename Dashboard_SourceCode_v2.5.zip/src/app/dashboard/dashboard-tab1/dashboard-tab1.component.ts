//"Copyright 2018 General Electric Company. All rights reserved."
import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import {DashboardComponent} from '../dashboard.component';

@Component({
  selector: 'app-dashboard-tab1',
  templateUrl: './dashboard-tab1.component.html',
  styleUrls: ['./dashboard-tab1.component.css'] 
})
export class DashboardTab1Component implements OnInit {
  public myInnerHeight: any;
  constructor(
    private DashboardComponentparent: DashboardComponent 
  ) {  
  }

  ngOnInit() { 
  }


//-------------------------------------------------------//
//making fullscreen of iframe with windows height  
//-------------------------------------------------------//
  fScreen(event) {
    //console.log('parent function was called');
    // event.target.classList.add('fullscreen'); // To ADD
    // event.target.classList.remove('fullscreen'); // To Remove
    // event.target.classList.close('click'); // To check 
    event.currentTarget.parentNode.parentNode.parentNode.classList.toggle('fullscreen');
    if (this.myInnerHeight + 100 !== window.innerHeight) {
      this.myInnerHeight = window.innerHeight - 100;
    } else {
      this.myInnerHeight = 600;
    }
  }  
}
