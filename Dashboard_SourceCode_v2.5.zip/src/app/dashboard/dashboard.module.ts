//© Copyright 2018-2019, GE
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { routing } from './dashboard.routing';
import { FormsModule } from '@angular/forms'; 
import { DashboardTab1Component } from './dashboard-tab1/dashboard-tab1.component';
import { DashboardTab2Component } from './dashboard-tab2/dashboard-tab2.component'; 



@NgModule({
  imports: [routing, CommonModule, FormsModule],
  declarations: [
    DashboardTab1Component,
    DashboardTab2Component, 
  ]
})
export class DashboardModule { }
