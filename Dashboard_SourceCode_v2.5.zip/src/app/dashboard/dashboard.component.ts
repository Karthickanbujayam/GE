//© Copyright 2018-2019, GE
import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';  

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  
})
export class DashboardComponent implements OnInit {
  public myInnerHeight: any;
  subscription: any;
  constructor( 
    private spinner: NgxSpinnerService, 
  ) { 
  }
  
  ngOnInit() {
    this.spinner.show();
  } 
}
