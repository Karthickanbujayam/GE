import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { DashboardCartsInfoComponent } from './dashboard-carts-info.component';

describe('DashboardComponent', () => {
  let component: DashboardCartsInfoComponent;
  let fixture: ComponentFixture<DashboardCartsInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardCartsInfoComponent ],
      imports: [BrowserModule],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ],
      providers: [ ]
    })
    .compileComponents();
  }));

  beforeEach(( ) => {
    fixture = TestBed.createComponent(DashboardCartsInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', ( ) => {
    expect(component).toBeTruthy();
  });
});
