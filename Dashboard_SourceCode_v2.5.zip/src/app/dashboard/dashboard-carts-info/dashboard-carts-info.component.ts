//"Copyright 2018 General Electric Company. All rights reserved."
/*
Here we going to display total number of test case from last the two month data 
and monitoring total number of success, failure and pending details in progress bar with sequence duration
like day, week and month.

And we are refreshing data based on program name with sequential time period(every one mint.). 
*/

//-------------------------------------------------------//
//importing the library components start here... 
//-------------------------------------------------------//
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgForm } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http/src/response';
declare var $: any;
import * as _ from 'lodash';
import { CartsInfoServices } from '../../services/dashboardService/carts-info.service';
import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
import { AlertifyService } from '../../services/alertify.service';
import { NgxSpinnerService } from 'ngx-spinner';



@Component({
  selector: 'app-dashboard-carts-info',
  templateUrl: './dashboard-carts-info.component.html',
  styleUrls: ['./dashboard-carts-info.component.scss']
})
export class DashboardCartsInfoComponent implements OnInit {

  //-------------------------------------------------------//
  //Declaring  variables start from here...
  //-------------------------------------------------------//
  
  programeNameList: any; 
  programeName: any; 
  total_success: any = 0;
  total_failure: any = 0;
  total_pending: any = 0;
  yesterday_success: any = 0;
  yesterday_failure: any = 0;
  yesterday_pending: any = 0;
  _2DayBefor_success: any = 0;
  _2DayBefor_failure: any = 0;
  _2DayBefor_pending: any = 0; 
  _7Day_success: any = 0;
  _7Day_failure: any = 0;
  _7Day_pending: any = 0;
  _30Day_success: any = 0;
  _30Day_failure: any = 0;
  _30Day_pending: any = 0;
  total_today: any = 0;
  total_yesterday: any = 0;
  total_7Days: any = 0;
  total_30Days: any = 0; 
  total_2dayBefore: any = 0;
  total_3dayBefore: any = 0;
  total_2weekBefore: any = 0;
  total_1monthBefore: any = 0;
  percentage_successToday: any = 0;
  percentage_failureToday: any = 0;
  percentage_pendingToday: any = 0;
  percentage_success_lastday: any = 0;
  percentage_failure_lastday: any = 0;
  percentage_pending_lastday: any = 0;
  percentage_success_last7day: any = 0;
  percentage_failure_last7day: any = 0;
  percentage_pending_last7day: any = 0;
  percentage_success_last30day: any = 0;
  percentage_failure_last30day: any = 0;
  percentage_pending_last30day: any = 0;
  today_status: any = '';
  yesterday_status: any = '';
  lastWeek_status: any = '';
  lastMonth_status: any = '';
  date_YYYYMMDD: any = Date.now();
  today: any = this.formatDate(new Date(Date.now()));
  yesterday: any = this.formatDate(new Date(Date.now() - 1 * 24 * 60 * 60 * 1000));
  _2dayBefore: any = this.formatDate(new Date(Date.now() - 2 * 24 * 60 * 60 * 1000));
  _3dayBefore: any = this.formatDate(new Date(Date.now() - 3 * 24 * 60 * 60 * 1000));
  week: any = this.formatDate(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000));
  secondWeek: any = this.formatDate(new Date(Date.now() - 14 * 24 * 60 * 60 * 1000));
  last_60Days: any = this.formatDate(new Date(Date.now() - 60 * 24 * 60 * 60 * 1000));
  last_30Days: any = this.formatDate(new Date(Date.now() - 30 * 24 * 60 * 60 * 1000));

  //-------------------------------------------------------//
  //Declaring  variables end to here...
  //-------------------------------------------------------// 

  //-------------------------------------------------------//
  //Calling service for GUI loading Bar start from here...
  //-------------------------------------------------------// 
  startLoading() { this.slimLoadingBarService.start(() => { console.log('Loading complete'); }); }
  stopLoading() { this.slimLoadingBarService.stop(); }
  completeLoading() { this.slimLoadingBarService.complete(); }
  //-------------------------------------------------------//
  //Calling service for GUI loading Bar end from here...
  //-------------------------------------------------------// 
  constructor(
    private CartsInfoService: CartsInfoServices,
    private slimLoadingBarService: SlimLoadingBarService,
    private alertify: AlertifyService,
    private spinner: NgxSpinnerService
  ) {

    //-------------------------------------------------------//
    //refreshing context name for cart-info GUI  start from here...
    //-------------------------------------------------------//

    setInterval(() => {
      if (this.programeNameList !== undefined) {
        this.programeName = this.programeNameList[Math.floor(Math.random() * this.programeNameList.length)];
        this.CartsInfoRefresh(this.programeName);
        console.log(this.programeName);
        console.log('CartsInfoRefresh');
      }

    }, 100000);

    //-------------------------------------------------------//
    //refreshing context name for cart-info GUI  end from here...
    //-------------------------------------------------------//

  }

  ngOnInit() {
    //-------------------------------------------------------//
    //Call the service for get context name  start from here...
    //-------------------------------------------------------//

    this.CartsInfoService.getKPINameList().subscribe(
      data => {
        this.spinner.show();
        if (data != null) {
          this.startLoading();
          let response = data as string[];		// FILL THE ARRAY WITH DATA.   
          response = _.filter(response);
          this.programeNameList = response;
          this.programeName = this.programeNameList[Math.floor(Math.random() * this.programeNameList.length)];
          this.CartsInfoRefresh(this.programeName);
        } else {
          this.programeName = 'No Data!';
        }
       // this.alertify.success('Successfully Picked Up The Programe Name!');
        this.spinner.hide();
      },
      (err: HttpErrorResponse) => {
        console.log(err);
        this.spinner.hide();
        this.alertify.error('Programe Name List - API Service has Down!');
      }
    );
    //-------------------------------------------------------//
    //Call the service for get context name  end from here...
    //-------------------------------------------------------//

  }

  //-------------------------------------------------------//
  //Formating date by using function start from here...
  //-------------------------------------------------------//
  formatDate(date) {
    //console.log(date);
    const year = date.getFullYear().toString();
    const month = (date.getMonth() + 101).toString().substring(1);
    const day = (date.getDate() + 100).toString().substring(1);
    return year + '-' + month + '-' + day;
  }

  percentCalculation(a, b, c) {
    let percentage: number;
    if (a != 0) {
      percentage = (parseFloat(a) / (parseFloat(a) + parseFloat(b) + parseFloat(c)) * 100);
    } else {
      return percentage = 0;
    }
    return Math.floor(percentage);
  }

  compare_dataPercentage(a, b) {
    let percentage: number;
    let result: string;

    if (a > b) {
      result = 'Greater than';
    } else if (a < b) {
      result = 'Lesser than';
    } else {
      result = 'Same as';
    }
    if (a !== 0 && b !== 0) {
      percentage = (parseFloat(a) / (parseFloat(b)) * 100) - 100;
    } else if (a !== 0 && b == 0) {
      percentage = a;
    } else {
      percentage = 0;
    }
    return (Math.round(percentage) + '%' + result);
  }

  //-------------------------------------------------------//
  //Formating date by using function end from here...
  //-------------------------------------------------------//
 

  pending(date_YYYYMMDD: any) {

    this.date_YYYYMMDD = date_YYYYMMDD;
    //today
    if (this.date_YYYYMMDD == this.today || this.date_YYYYMMDD == this.yesterday) {
      this.total_pending += 1;
      this.total_today += 1;
    }
    //yesterday - 
    if (this.date_YYYYMMDD == this.yesterday) {
      this.total_yesterday += 1;
    } 

    //_2dayBefore
    if (this.date_YYYYMMDD == this._2dayBefore) {
      this._2DayBefor_pending += 1; 
      this.total_2dayBefore += 1;
    }
     //_3dayBefore
     if (this.date_YYYYMMDD == this._3dayBefore) {
      this.total_3dayBefore += 1;
    }

    //Week
    if (this.week < this.date_YYYYMMDD || this.date_YYYYMMDD > this._2dayBefore) {
      this._7Day_pending += 1;
      this.total_7Days += 1;
    }
    //secondWeek
    if (this._2dayBefore < this.date_YYYYMMDD || this.date_YYYYMMDD > this.secondWeek) {
      this.total_2weekBefore += 1;
    }
    //Month
    if (this.today < this.date_YYYYMMDD || this.date_YYYYMMDD > this.last_30Days) {
      this._30Day_pending += 1;
      this.total_30Days += 1;
    }
     
    //lastMonth
    if (this.last_30Days < this.date_YYYYMMDD || this.date_YYYYMMDD > this.last_60Days) {
      this.total_1monthBefore += 1;
    }
    
  }


  failedExecution(date_YYYYMMDD: any) {

    this.date_YYYYMMDD = date_YYYYMMDD;
    //today
    if (this.date_YYYYMMDD == this.today || this.date_YYYYMMDD == this.yesterday) {
      this.total_failure += 1;
      this.total_today += 1;
    }

    //yesterday - 
    if (this.date_YYYYMMDD == this.yesterday) {
      this.total_yesterday += 1;
    }
    //_2dayBefore
    if (this.date_YYYYMMDD == this._2dayBefore) {
      this._2DayBefor_failure += 1; 
      this.total_2dayBefore += 1;
    }

     //_3dayBefore
     if (this.date_YYYYMMDD == this._3dayBefore) {
      this.total_3dayBefore += 1;
    }

    //secondWeek
    if (this._2dayBefore < this.date_YYYYMMDD || this.date_YYYYMMDD > this.secondWeek) {
      this.total_2weekBefore += 1;
    }

    //Week
    if (this.week < this.date_YYYYMMDD || this.date_YYYYMMDD > this._2dayBefore) {
      this._7Day_failure += 1;
      this.total_7Days += 1;
    }

    //Month
    if (this.today < this.date_YYYYMMDD || this.date_YYYYMMDD > this.last_30Days) {
      this._30Day_failure += 1;
      this.total_30Days += 1;
    }
 
    //lastMonth
    if (this.last_30Days < this.date_YYYYMMDD || this.date_YYYYMMDD > this.last_60Days) {
      this.total_1monthBefore += 1;
    }

  }

  passed(date_YYYYMMDD: any) {
    this.date_YYYYMMDD = date_YYYYMMDD;

    //today
    if (this.date_YYYYMMDD == this.today) {
      this.total_success += 1;
      this.total_today += 1;
    }

    //yesterday - 
    if (this.date_YYYYMMDD == this.yesterday) {
      this.total_yesterday += 1; 
    }

    // _2dayBefore
    if (this.date_YYYYMMDD == this._2dayBefore) {
      this._2DayBefor_success += 1; 
      this.total_2dayBefore += 1;

    }

     //_3dayBefore
     if (this.date_YYYYMMDD == this._3dayBefore) {
      this.total_3dayBefore += 1;
    }

    //Week
    if (this.week < this.date_YYYYMMDD || this.date_YYYYMMDD > this._2dayBefore) {
      this._7Day_success += 1;
      this.total_7Days += 1;

    }

    //secondWeek
    if (this._2dayBefore < this.date_YYYYMMDD || this.date_YYYYMMDD > this.secondWeek) {
      this.total_2weekBefore += 1; 
    }

    //Month
    if (this.today < this.date_YYYYMMDD || this.date_YYYYMMDD > this.last_30Days) {
      this._30Day_success += 1;
      this.total_30Days += 1;

    } 
    
    //lastMonth
    if (this.last_30Days < this.date_YYYYMMDD || this.date_YYYYMMDD > this.last_60Days) {
      this.total_1monthBefore += 1;

    }

  }


  //----------------------------------------------------------------------------------//
  //Business logies for refreshing data into cart-info by time period start from here...
  //----------------------------------------------------------------------------------//

  filterByProgramName(filterVal: any) {
    this.CartsInfoRefresh(filterVal);
  }
  


  CartsInfoRefresh(programeName) {
    console.log(programeName);
    this.startLoading();
    this.today_status = '';
    this.yesterday_status = '';
    this.lastWeek_status = '';
    this.lastMonth_status = '';
    this.total_success = 0;
    this.total_failure = 0;
    this.total_pending = 0;
    this._2DayBefor_success = 0;
    this._2DayBefor_failure = 0;
    this._2DayBefor_pending = 0
    this._7Day_success = 0;
    this._7Day_failure = 0;
    this._7Day_pending = 0
    this._30Day_success = 0;
    this._30Day_failure = 0;
    this._30Day_pending = 0;
    this.total_today = 0;
    this.total_yesterday = 0;
    this.total_2dayBefore=0;
    this.total_7Days = 0;
    this.total_30Days = 0;


    this.CartsInfoService.CartsInfoRefresh(programeName).subscribe(
      data => {
        if (data != null) {
          //let response = data as string[];		// FILL THE ARRAY WITH DATA.  
          const response = _.filter(data);
          //console.log(response);
          for (let i = 0; i < response[0].length; i++) {
            const status = response[0][i];
            this.date_YYYYMMDD = this.formatDate(new Date(response[0][i].Date));
            console.log(status.Result);
            switch (status.Result) {
              case 'Failed Execution':
                this.failedExecution(this.date_YYYYMMDD);
                break;
              case 'Failed Verification':
                this.failedExecution(this.date_YYYYMMDD);
                break;
              // case 'Failed Verification':
              //   this.failedVerification(this.date_YYYYMMDD);
              //   break;
              case 'Pending':
                this.pending(this.date_YYYYMMDD);
                break;
              case 'None':
                this.pending(this.date_YYYYMMDD);
                break;
              case 'Passed':
                this.passed(this.date_YYYYMMDD);
                break;
            }
          }
        } else {
          console.log("404")
          this.total_yesterday = 0;
          this.total_2dayBefore = 0;
          this.total_1monthBefore = 0;
          this.total_2weekBefore = 0;
          this.total_success = 0;
          this.total_failure = 0;
          this.total_pending = 0;
          this._2DayBefor_success = 0;
          this._2DayBefor_failure = 0;
          this._2DayBefor_pending = 0
          this._7Day_success = 0;
          this._7Day_failure = 0;
          this._7Day_pending = 0
          this._30Day_success = 0;
          this._30Day_failure = 0;
          this._30Day_pending = 0;
          this.total_today = 0;
          this.total_yesterday = 0;
          this.total_7Days = 0;
          this.total_30Days = 0;
        }

        this.percentage_successToday = this.percentCalculation(this.total_success, this.total_failure, this.total_pending);
        this.percentage_failureToday = this.percentCalculation(this.total_failure, this.total_success, this.total_pending);
        this.percentage_pendingToday = this.percentCalculation(this.total_pending, this.total_success, this.total_failure);

        this.percentage_success_lastday = this.percentCalculation(this._2DayBefor_success, this._2DayBefor_failure, this._2DayBefor_pending);
        this.percentage_failure_lastday = this.percentCalculation(this._2DayBefor_failure, this._2DayBefor_success, this._2DayBefor_pending);
        this.percentage_pending_lastday = this.percentCalculation(this._2DayBefor_pending, this._2DayBefor_success, this._2DayBefor_failure);

        this.percentage_success_last7day = this.percentCalculation(this._7Day_success, this._7Day_failure, this._7Day_pending);
        this.percentage_failure_last7day = this.percentCalculation(this._7Day_failure, this._7Day_success, this._7Day_pending);
        this.percentage_pending_last7day = this.percentCalculation(this._7Day_pending, this._7Day_success, this._7Day_failure);

        this.percentage_success_last30day = this.percentCalculation(this._30Day_success, this._30Day_failure, this._30Day_pending);
        this.percentage_failure_last30day = this.percentCalculation(this._30Day_failure, this._30Day_success, this._30Day_pending);
        this.percentage_pending_last30day = this.percentCalculation(this._30Day_pending, this._30Day_success, this._30Day_failure);

        this.today_status = this.compare_dataPercentage(this.total_today, this.total_yesterday);
        this.yesterday_status = this.compare_dataPercentage(this.total_2dayBefore, this.total_3dayBefore);
        this.lastWeek_status = this.compare_dataPercentage(this.total_7Days, this.total_2weekBefore);
        this.lastMonth_status = this.compare_dataPercentage(this.total_30Days, this.total_1monthBefore);  
          
        this.completeLoading();
        this.spinner.hide();

        //this.alertify.success('Successfully Picked Up two month data based on the The Program Name from KIBANA!');
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
        this.alertify.error('Cart Info - API Service has Down!');
      }
    ); 
  } 

  // createJSON(){
  //   let jsonObj = [];
  //   let today_details = [];
  //   let last2days_details = [];
  //   let last7days_details = [];
  //   let last30days_details = [];

  //   jsonObj.push({
  //     icon:'fa fa-cube fa-5x',
  //     total_testCase_today : this.total_today,
  //     total_success_today : this.total_success,
  //     total_failure_today : this.total_failure,
  //     total_pending_today : this.total_pending,  
  //     percentage_successToday : this.percentage_successToday,
  //     percentage_failureToday :  this.percentage_failureToday,
  //     percentage_pendingToday: this.percentage_pendingToday,
  //     total_yesterday : this.total_yesterday,
  //     today_status:  this.today_status 
  //   }); 

  //   jsonObj.push({
  //     icon:'fa fa-codepen fa-5x',
  //     total_testCase_today : this.total_2dayBefore,
  //     total_success_today : this._2DayBefor_success,
  //     total_failure_today : this._2DayBefor_failure,
  //     total_pending_today : this._2DayBefor_pending,  
  //     percentage_success_lastday : this.percentage_success_lastday,
  //     percentage_failure_lastday :  this.percentage_failure_lastday,
  //     percentage_pending_lastday: this.percentage_pending_lastday,
  //     total_yesterday : this.total_3dayBefore,
  //     today_status:  this.yesterday_status 
  //   }); 

  //   jsonObj.push({
  //     icon:'fa fa-cubes fa-5x',
  //     total_testCase_today : this.total_7Days,
  //     total_success_today : this._7Day_success,
  //     total_failure_today : this._7Day_failure,
  //     total_pending_today : this._7Day_pending,  
  //     percentage_success_lastday : this.percentage_success_last7day,
  //     percentage_failure_lastday :  this.percentage_failure_last7day,
  //     percentage_pending_lastday: this.percentage_pending_last7day,
  //     total_yesterday : this.total_2weekBefore,
  //     today_status:  this.yesterday_status 
  //   });
  
    
  //   jsonObj.push({
  //   icon:'fa fa-connectdevelop fa-5x',
  //   total_testCase_today : this.total_30Days,
  //   total_success_today : this._30Day_success,
  //   total_failure_today : this._30Day_failure,
  //   total_pending_today : this._30Day_pending,  
  //   percentage_success_lastday : this.percentage_success_last30day,
  //   percentage_failure_lastday : this.percentage_failure_last30day,
  //   percentage_pending_lastday: this.percentage_pending_last30day,
  //   total_yesterday : this.total_1monthBefore,
  //   today_status:  this.lastMonth_status 
  // }); 

  //   let item = {}
  //   item ['program_Name'] =  this.programeName; 
  //   jsonObj.push(item);

  //   console.log("********************" + JSON.stringify(jsonObj));

  //   return jsonObj;

  // }
 
  
  //----------------------------------------------------------------------------------//
  //Business logies for refreshing data into cart-info by time period end from here...
  //----------------------------------------------------------------------------------//
}


