const express = require('express');
const router = express.Router();
const fs = require('fs'); 

/* GET api listing. */
router.get('/favorites', (req, res) => { 
  fs.readFile('./server/routes/favorites.json', 'utf8', function (err, data) {
    if (err) 
       // error handling
       console.log(err + "***********");

    var obj = JSON.parse(data);
    console.log("**********"+ obj);
    res.send(obj);
  });

});
 

module.exports = router;
 